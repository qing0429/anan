
-- 初始化数据
-- isee_00.isee_data_dictionary 数据初始化
INSERT INTO `isee_data_dictionary` (`type`, `type_name`, `code`, `code_value`, `remark`, `creator`, `gmt_created`, `modifier`, `gmt_modified`, `is_deleted`) VALUES
	('ID type', '证件类型', 'TB', '台湾居民来往内地通行证', '投保人、被保人投保时的证件类型', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'Y'),
	('ID type', '证件类型', 'I', '身份证', '', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'Y'),
	('ID type', '证件类型', 'P', '护照', '', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'Y'),
	('ID type', '证件类型', 'GJ', '港澳居民来往内地通行证', '', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'Y'),
	('QUALITY_05_LIMIT', '质检限制规则', 'MIN_TIME', '15000', '', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('QUALITY_05_LIMIT', '质检限制规则', 'MAX_TIME', '1800000', '', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'ProblemTypeEnum', '问题类型', '0', '视频串联', NULL, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'ProblemTypeEnum', '问题类型', '2', '保单与视频不匹配', NULL, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'ProblemTypeEnum', '问题类型', '3', '页面丢失', NULL, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'ProblemTypeEnum', '问题类型', '4', '样式错乱', NULL, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'ProblemTypeEnum', '问题类型', '5', '局部缺失/有误', NULL, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'ProblemTypeEnum', '问题类型', '6', '其他', NULL, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N');

-- isee_00.isee_function 数据初始化
INSERT INTO `isee_function` VALUES (1, 'M00001', '产品管理', '/insurance', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (2, 'M000011', '产品查询', 'list', 13, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/coreProduct/list');
INSERT INTO `isee_function` VALUES (3, 'M00002', '销售回溯管理', '/', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'Y', NULL);
INSERT INTO `isee_function` VALUES (4, 'M000021', '视频回溯管理', 'manager', 97, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/video/query,/video/detailNew,/video/log/list,/serverconfig.json,/user/info,/user/auth,/common/queryDictionary,/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply,/video/apply/query,/video/extraPair');
INSERT INTO `isee_function` VALUES (5, 'M00003', '客诉管理', '/complain', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (6, 'M000031', '客诉管理', 'complainList', 5, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/complaint/query,/complaint/addOrProcess,/video/policy/query,/video/detailNew,/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply');
INSERT INTO `isee_function` VALUES (7, 'M00004', '区块链视频验真', '/chain', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (8, 'M000041', '区块链视频验真', 'chainList', 7, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/video/validation/list,/video/validate');
INSERT INTO `isee_function` VALUES (9, 'M00005', '归档管理', '/archive', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (10, 'M000051', '归档历史查询', 'archiveList', 9, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/archive/query,/archive/apply');
INSERT INTO `isee_function` VALUES (11, 'M000052', '我的调档申请', 'applyList', 9, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/archive/apply/mine');
INSERT INTO `isee_function` VALUES (12, 'M000053', '调档申请审核', 'auditList', 9, 3, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/archive/apply/queryAll,/archive/apply/audit');
INSERT INTO `isee_function` VALUES (13, 'M00007', '配置管理', '/config', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (14, 'M000071', '机构管理', 'agency', 99, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/agency/upload,/agency/query,/agency/add');
INSERT INTO `isee_function` VALUES (16, 'M000073', '字典配置', 'dictionary', 18, 5, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/data/dict/query,/data/dict/addOrUpdate,/data/dict/delete');
INSERT INTO `isee_function` VALUES (17, 'M000074', '系统参数', 'param', 18, 6, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/system/config/query,/system/config/queryByCondition,/system/config/addOrUpdate');
INSERT INTO `isee_function` VALUES (18, 'M00008', '系统管理', '/system', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (19, 'M000081', '账号管理', 'accountList', 99, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/user/query,/user/add,/user/reset/password,/user/delete');
INSERT INTO `isee_function` VALUES (20, 'M000082', '角色管理', 'role', 99, 3, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/role/list,/role/save,/role/delete');
INSERT INTO `isee_function` VALUES (21, 'M000083', '功能权限管理', 'feature', 99, 4, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/role/list,/role/user/detail,/role/user/save,/role/func/detail,/role/func/save,');
INSERT INTO `isee_function` VALUES (22, 'M000084', '数据权限管理', 'data', 99, 5, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/agency/auth/list,/agency/auth/save,/agency/auth/delete');
INSERT INTO `isee_function` VALUES (23, 'M000085', '日志管理', 'log', 18, 7, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/audit/list');
INSERT INTO `isee_function` VALUES (24, 'M0000211', '播放视频', 'cameraplay', 4, 1, 3, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (25, 'M0000851', '查询', '/audit/list', 23, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (26, 'M0000811', '新增/修改', '/user/add', 19, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (27, 'M0000812', '删除', '/user/delete', 19, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (28, 'M0000821', '新增/修改', '/role/save', 20, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (29, 'M0000822', '查询', '/role/list', 20, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (30, 'M0000823', '删除', '/role/delete', 20, 3, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (31, 'M0000832', '关联账号', '/role/user/save', 21, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (32, 'M0000833', '功能授权', '/role/func/save', 21, 3, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (33, 'M0000841', '数据授权', '/agency/auth/save', 22, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (34, 'M0000842', '查询', '/agency/auth/list', 22, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (35, 'M0000711', '批量导入', '/agency/upload', 14, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (36, 'M0000712', '加载机构列表', '/agency/load', 14, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (38, 'M0000731', '新增/修改', '/data/dict/addOrUpdate', 16, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (39, 'M0000732', '查询', '/data/dict/query', 16, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (40, 'M0000733', '删除', '/data/dict/delete', 16, 3, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (41, 'M0000741', '查询', '/system/config/query', 17, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (42, 'M0000742', '新增/修改', '/system/config/addOrUpdate', 17, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (43, 'M0000511', '查询', '/archive/query', 10, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (44, 'M0000512', '调档申请', '/archive/apply', 10, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (45, 'M0000521', '查询', '/archive/apply/mine', 11, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (46, 'M0000531', '查询', '/archive/apply/queryAll', 12, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (47, 'M0000532', '审批', '/archive/apply/audit', 12, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (48, 'M0000411', '视频验真', '/video/validate', 8, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (49, 'M0000412', '查询', '/video/validation/list', 8, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (50, 'M0000311', '新增/修改', '/complaint/addOrProcess', 6, 1, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (51, 'M0000312', '查询', '/complaint/query', 6, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (52, 'M0000313', '查看视频', '/video/policy/query', 6, 3, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (53, 'M0000212', '查询', '/video/query', 4, 2, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (54, 'M0000213', '查看详情', '/video/detail', 4, 3, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (55, 'M0000111', '查询', '/product/list', 2, 3, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (56, 'M0000112', '新增/修改', '/product/addOrUpdate', 2, 3, 3, 2, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (59, 'M0000214', '播放虚拟视频', 'cameraplayv2', 4, 2, 3, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (60, 'M0000215', '查看视频3', 'cameraplayv3', 4, 3, 3, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'Y', NULL);
INSERT INTO `isee_function` VALUES (62, 'M000075', '渠道管理', 'channel', 13, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (63, 'M00006', '视频输出管理', '/videooutput', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (64, 'M000061', '视频输出管理', 'volist', 63, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/video/apply/query,/video/download/stream');
INSERT INTO `isee_function` VALUES (65, 'M00009', '回溯数据分析', '/visualize', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (66, 'M000091', '回溯整体概况分析', 'overview', 65, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/report/video/total,/report/video/channel,/report/video/channel/daily,/report/video/top');
INSERT INTO `isee_function` VALUES (67, 'M000092', '平台运行监控分析', 'health', 65, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, '', CURRENT_TIMESTAMP, 'N', '/function/sub,/report/analysis/total,/report/analysis/channel,/report/analysis/channel/daily,/report/analysis/translet');
INSERT INTO `isee_function` VALUES (68, 'M000087', '异常视频查询', 'exvideo', 18, 9, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (69, 'M000088', '播放虚拟视频', 'exdetailv2', 68, 10, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (70, 'M000076', '播放视频', 'exdetail', 68, 11, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/hosts/list,/page/list,/page');
INSERT INTO `isee_function` VALUES (71, 'M000077', '流程节点管理', 'page', 13, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/hosts/list,/page/list,/page');
INSERT INTO `isee_function` VALUES (72, 'M000078', '回溯流程配置', 'businessrule', 13, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/processRef,/page/all,/hosts/list,/process/list,/processCheck,/process,/process/{processCode}');
INSERT INTO `isee_function` VALUES (73, 'M000078', '域名管理', 'host', 13, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/hosts/query,/hosts');
INSERT INTO `isee_function` VALUES (74, 'M00011', '对账管理', '/checking', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (75, 'M000111', '对账汇总报表', 'total', 74, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/reconc/total,/agency/load,/reconc/downloadDetail/{reconcSerial},/reconc/downloadTotal,/reconc/remark,/reconc/repair/{reconcSerial}/{type},');
INSERT INTO `isee_function` VALUES (76, 'M000112', '对账差异报表', 'diff', 74, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/reconc/diffReport,/agency/load,/reconc/diff,/reconc/reviewDiff,/reconc/downloadDiff');
INSERT INTO `isee_function` VALUES (77, 'M00012', '质检管理', '/qa', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (78, 'M000121', '质检规则配置', 'ruleconfig', 77, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/quality/testing/rule/list,/quality/testing/rule/change/state');
INSERT INTO `isee_function` VALUES (79, 'M000122', '自动质检报表', 'autoexecReport', 77, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/quality/testing/statement/list,/quality/testing/statement/list/download');
INSERT INTO `isee_function` VALUES (80, 'M000123', '质检跟进件管理', 'follow', 77, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/quality/testing/rule/list,/agency/load,/quality/testing/item/list,/quality/testing/item/{id},/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply,/quality/testing/item/recheck,/quality/testing/item/list/download');
INSERT INTO `isee_function` VALUES (81, 'M000124', '复检视频', 'review', 77, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (82, 'M000125', '人工抽检', 'manual', 77, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/quality/testing/rule/list,/agency/load,/quality/manual/list,/coreProduct/list,/quality/manual/random/rule/query,/quality/manual/random/rule,/quality/manual/detail/{id},/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply,/quality/manual/recheck,/quality/manual/download,/quality/manual/directional/extract');
INSERT INTO `isee_function` VALUES (83, 'M000126', '质检视频', 'manualReview', 77, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (84, 'M00013', '回溯异常管理', '/exception', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (86, 'M000131', '回溯异常管理', 'exceptionManage', 84, 2, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/quality/unnormal/list,/quality/unnormal/download');
INSERT INTO `isee_function` VALUES (94, 'M00015', '回溯流程管理', '/traceprogress', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'Y', NULL);
INSERT INTO `isee_function` VALUES (96, 'M000152', '操作轨迹管理', 'operate', 97, 3, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/agency/load,/video/query,/trace/log,/insure/page/code');
INSERT INTO `isee_function` VALUES (97, 'M000153', '回溯数据采集', '/', 0, 1, 1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);
INSERT INTO `isee_function` VALUES (100, 'M000151', '版本管理', 'version', 98, 1, 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '/function/sub,/gallery/photo/list/page,/insure/flow/page/list,/gallery/photo/batch/upload,/insure/flow/add,/insure/page/add,/insure/flow/delete,/insure/flow/snapshotOperation,/insure/flow/queryByVersion,/insure/flow/file/upload,/insure/flow/file/add,/insure/flow/file/delete,/gallery/photo/delete,/insure/page/update,/insure/page/delete');


-- isee_00.isee_user 数据初始化
INSERT INTO `isee_user` (`id`, `agency_code`, `agency_name`, `user_name`, `name_pinyin`, `login_name`, `password`, `certi_type`, `certi_no`, `mobile`, `email`, `address`, `remark`, `status`, `creator`, `gmt_created`, `modifier`, `gmt_modified`, `is_deleted`) VALUES
	(1, '', '', 'admin', 'admin', 'admin', '7b70ca0492b030fd35f00e51059823e7', NULL, NULL, '13200001110', 'admin@zhongan.io', NULL, NULL, '0', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N');

-- isee_00.isee_role 数据初始化
INSERT INTO `isee_role` (`id`, `role_name`, `remark`, `creator`, `gmt_created`, `modifier`, `gmt_modified`, `is_deleted`) VALUES
	(1, '超级管理员', '全部菜单权限的超级管理员', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N');

-- isee_00.isee_role_func 数据初始化
INSERT INTO `isee_role_func` (`func_code`, `role_id`, `creator`, `gmt_created`, `modifier`, `gmt_modified`, `is_deleted`) VALUES

	( 'M00007', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00008', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00001', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00002', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000021', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000211', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000212', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000213', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000214', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00003', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000031', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000311', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000312', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000313', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00004', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000041', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000411', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000412', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00005', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000051', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000511', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000512', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000052', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000521', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000053', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000531', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000532', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000011', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000111', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000112', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000071', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000711', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000712', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000076', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000077', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000078', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000073', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000731', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000732', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000733', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000074', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000741', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000742', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000081', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000811', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000812', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000082', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000821', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000822', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000823', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000083', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000832', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000833', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000084', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000841', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000842', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000085', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M0000851', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000086', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000087', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000088', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000089', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00006', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000061', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00009', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000091', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000092', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00011', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000111', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000112', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00012', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000121', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000122', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000123', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000124', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M00015', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000151', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( 'M000152', 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N');


-- isee_00.isee_role_user 数据初始化
INSERT INTO `isee_role_user` (`uid`, `role_id`, `creator`, `gmt_created`, `modifier`, `gmt_modified`, `is_deleted`) VALUES
	(1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N');


-- isee_00.isee_system_config 数据初始化
INSERT INTO `isee_system_config` (`param_name`, `property_key`, `property_value`, `remark`, `creator`, `gmt_created`, `modifier`, `gmt_modified`, `is_deleted`) VALUES
	('机构导入模板', 'AGENCY_TEMP', 'https://static.zhongan.com/website/isee/agency_upload_template.xls', '机构导入模板OSS地址', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('产品导入模板', 'PRODUCT_TEMP', 'https://static.zhongan.com/website/isee/product_upload_template.xls', '产品导入模板OSS地址', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('长险存储年限', 'LS_STORE_YEAR', '10', '若保险产品为长险，则存储时间至少应为10年,单位（年）', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('短险存储年限', 'SS_STORE_YEAR', '5', '若保险产品为短险，则存储时间至少应为5年，单位（年）', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('理赔延长存储年限', 'CLAIM_STORE_YEAR', '2', '若保单有理赔，则存储时间应在原基础上延长2年，单位（年）', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '自动归档时间', 'ARCHIVE_STORE_DAY', '365', '为节约存储空间，视频生成后的某一期限内则系统自动归档，单位（天）', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '视频销售回溯管理视频下载开关是否可见', 'VIDEO_DOWNLOAD_SHOW', '1', '1 - 可见 ； 0 -不可见', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '加密盐值', 'SALT_KEY', 'ISEE', '加密盐值', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '静态库文件类型', 'STATIC_RESOURCE_EXTENSION', '.gif|.jpg|.jpeg|.png|.tif|.tiff|.bmp|.avi|.mov|.css|.pdf|.eot|.woff|.ttf|.svg', '静态资源库支持的数据格式', 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP, 'N'),
	( '是否启用静态库', 'STATIC_RESOURCE_ENABLE', 'true', '是否启用静态库 false - 不启用；true - 启用', 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP, 'N'),
	( '是否自动生成视频', 'AUTO_GENERATE_VIDEO_ENABLE', 'false', '系统是否自动触发视频生成操作 false - 不启用；true - 启用', 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP, 'N'),
	( '视频回放帧最大时间间隔', 'MAX_VIDEO_STEP_MIL', '1000', '视频回放帧最大时间间隔，单位毫秒，-1代表不调整播放时间', 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP, 'N'),
	( '视频回溯码生成后未离开开始页的有效期', 'ISEEBIZ_INIT_EXPIRE', '1', '视频回溯码生成后未离开开始页的有效期（单位秒）- 有效期内刷新页面不会产生新的业务回溯码', 'system', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '视频回溯码生成后离开开始页后的有效期', 'ISEEBIZ_OFFLINE_EXPIRE', '1', '视频回溯码生成后离开开始页后的有效期（单位秒）- 有效期内返回相同起始页，不会产生新的业务回溯码', 'system', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '是否启用直播', 'LIVE_VIDEO_ENABLE', 'false', '是否启用直播 false - 不启用；true - 启用', 'system', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '千里眼插件迭代版本', 'PLUGIN_VERSION', '2119:0;2120:100', '千里眼插件版本（迭代版本），格式：版本号:流量比例;版本号:流量比例 （版本号：前端插件版本号，流量比例：单位（%），数值范围0-100，保留2位小数）', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '最大单条业务回溯码占用空间大小', 'MAX_RECORD_MEMORY', '41943040', '最大单条业务回溯码占用空间大小，单位字节', 'system', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '最大单条业务回溯码记录数', 'MAX_RECORD_SIZE', '5000', '最大单条业务回溯码记录数', 'system', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '静态资源忽略列表', 'STATIC_RESOURCE_EXCLUDE_REG', 'placeholder.jpg|sdk_app.gif|isee-mock|https://static.zhongan.com/website/mobile/html/public/pdf/index.html?', '包含列表中内容的静态资源无需上传静态服务器', 'system', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '前端日志开关', 'ENABLE_ISEE_FRONT_LOG', 'false', '是否打印前端环境操作日志', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '千里眼插件稳定版本', 'PLUGIN_VERSION_STABLE', '2118', '千里眼插件稳定版本（直营直购专属版本）', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '最大单条业务回溯码有效时间窗口', 'MAX_RECORD_WINDOW', '3600', '时间有效窗口单位秒s', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '回溯码设备号缓存时间', 'ISEE_DEVICE_CACHE_TIME', '64800', '秒', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '阿里云编排消息通知', 'OPEN_ALILOG_MESSAGE', 'true', '是否开启阿里云消息通知 true false', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '回溯码消息发送延迟时间', 'ISEE_MESSAGE_DELAY_TIME', '180', '单位秒', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '阿里云日志最大存储时间', 'MAX_LOG_EXPIRE_DAY', '14', '单位天，此配置影响是否可修复对账数据', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '人工质检随机抽样数量', 'QUALITY_RANDOM_AMOUNT', '30', '人工质检随机抽样数量', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '人工质检随机抽样开关', 'QUALITY_RANDOM_SWITCH', 'N', '人工质检随机抽样开关', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '是否开启阿里云日志服务', 'OPEN_ALILOG_SERVICE', 'true', 'true 开始 false 关闭', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	( '非连续投保缓存时间', 'BREAKPOINT_RESUME_CACHE', '432000', '非连续投保场景缓存时间单位秒', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('采集端SDK应用授权ID', 'SYSTEM_SDK_APPID', 'zhonganIsee', '对SDK端提供的APPID,IOS,安卓,微信小程序，支付宝小程序等', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('采集端SDK版本号', 'SYSTEM_SDK_VERSION', '1.0.0', '标记SDK版本号-暂未使用', 'admin',CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N'),
	('采集端SDK开放来源', 'SYSTEM_SDK_SOURCE_ENABLE', 'IOS,ANDROID,H5,WX-MINI,ZFB-MINI', 'IOS:苹果原生 ANDROID:安卓原生 H5:非plugin H5 SDK  WX-MINI:微信小程序 ZFB-MINI:支付宝小程序\n支持列表配置，逗号分隔', 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N');

-- isee_00.isee_quality_testing_rule 质检规则数据初始化
 INSERT INTO `isee_quality_testing_rule`( `code`, `rule_name`, `rule_desc`, `priority`, `status`, `creator`, `gmt_created`, `modifier`, `gmt_modified`, `is_deleted`, `params`) values
 ('RESOURCE_DOWNLOAD_ERROR', '图片样式检测', '静态文件下载失败，部分图片不显示或者显示异常', 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL),
 ('BASE64_EMPTY', '图片显示检测', 'Base64为空，部分图片显示白图或黑图', 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL),
 ('CIRCUIT_BREAK', '熔断机制检测', '前端收集触发熔断', 1, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL),
 ('VIDEO_DURATION_MIN', '视频长度超短检测', '视频过短', 3, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '10000'),
 ('VIDEO_DURATION_MAX', '视频长度超长检测', '视频过长', 3, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '20000'),
 ('ISEE_BIZ_AGING', '回溯码时效检测', '回溯码生成时间过久，视频不完整', 2, 1, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', '10000'),
 ('START_PAGE_REGULAR', '开始页面配置正则检测', '起止页正则路由有误', 1, 0, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL),
 ('UNCONFIG_ROUTING', '开始页面已配置检测', '未配置起始页路由', 1, 0, 'admin', CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'N', NULL);