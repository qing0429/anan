
-- --------------------------------------------------------
-- 主机:                           rm-bp1w6o2hi8mm0lkn6.mysql.rds.aliyuncs.com
-- 服务器版本:                        5.6.16-log - Source distribution
-- 服务器操作系统:                      Linux
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------


--  isee_00.isee_agency 结构
CREATE TABLE IF NOT EXISTS `isee_agency` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `code` varchar(50) NOT NULL COMMENT '机构编码',
  `name` varchar(128) NOT NULL COMMENT '机构名称',
  `level` tinyint(4) DEFAULT '1' COMMENT '机构级别',
  `order` int(10) DEFAULT NULL COMMENT '相同机构级别内序号',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '上级机构编码',
  `parent_name` varchar(50) DEFAULT NULL COMMENT '上级机构名称',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='机构';



--  isee_00.isee_agency_auth 结构
CREATE TABLE IF NOT EXISTS `isee_agency_auth` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `agency_code` varchar(50) NOT NULL COMMENT '授权机构代码',
  `authorized_agency_code` varchar(50) NOT NULL COMMENT '被授权机构代码',
  `expire_date` datetime DEFAULT NULL COMMENT '授权失效时间',
  `creator` varchar(50) NOT NULL COMMENT '授权人',
  `gmt_created` datetime NOT NULL COMMENT '授权时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='机构授权表';



--  isee_00.isee_api_log 结构
CREATE TABLE IF NOT EXISTS `isee_api_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `request_ip` varchar(128) DEFAULT NULL COMMENT '请求方ip',
  `source` varchar(64) DEFAULT NULL COMMENT '请求来源',
  `request_sign` varchar(128) DEFAULT NULL COMMENT '请求sign',
  `request_uuid` varchar(128) DEFAULT NULL COMMENT '请求流水号',
  `request_type` char(2) DEFAULT NULL COMMENT '业务类型',
  `request_time` datetime DEFAULT NULL COMMENT '业务方请求时间',
  `request_body` varchar(2048) DEFAULT NULL COMMENT '请求报文',
  `extra_biz` varchar(128) DEFAULT NULL COMMENT '业务请求id,拓展冗余',
  `response_uuid` varchar(128) DEFAULT NULL COMMENT '返回流水号',
  `response_code` varchar(10) DEFAULT NULL COMMENT '返回状态',
  `response_body` varchar(1024) DEFAULT NULL COMMENT '返回报文',
  `process_cost` int(11) DEFAULT NULL COMMENT '处理耗时',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_req` (`request_uuid`),
  KEY `idx_biz` (`extra_biz`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='对外接口日志表';



-- isee_00.isee_audit 结构
CREATE TABLE IF NOT EXISTS `isee_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `uid` bigint(20) unsigned NOT NULL COMMENT '用户编号',
  `login_name` varchar(50) NOT NULL COMMENT '登录名',
  `client_ip` varchar(50) NOT NULL COMMENT '客户端IP',
  `server_ip` varchar(50) NOT NULL COMMENT '访问服务端IP',
  `func_id` bigint(20) unsigned DEFAULT NULL COMMENT '菜单编号',
  `func_name` varchar(50) DEFAULT NULL COMMENT '菜单名称',
  `operation` varchar(2000) DEFAULT NULL COMMENT '操作（请求内容）',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否逻辑删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='审计表(系统操作日志)';

--  isee_00.isee_channel 结构
CREATE TABLE IF NOT EXISTS `isee_channel` (
  `id` bigint(20) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `name` varchar(100) DEFAULT NULL COMMENT '渠道名称',
  `agency_code` varchar(50) DEFAULT NULL COMMENT '机构编码',
  `host` varchar(100) DEFAULT NULL COMMENT 'host',
  `creator` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `code` varchar(10) DEFAULT NULL COMMENT '渠道编码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='渠道表';



--  isee_00.isee_code_table 结构
CREATE TABLE IF NOT EXISTS `isee_code_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `code` varchar(50) DEFAULT NULL COMMENT '代码',
  `value` varchar(200) DEFAULT NULL COMMENT '值',
  `type` varchar(20) DEFAULT NULL COMMENT '类型',
  `parent_id` varchar(6) DEFAULT NULL COMMENT '上级id',
  `extra_info` varchar(100) DEFAULT '' COMMENT '额外信息',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否逻辑删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='码表';



--  isee_00.isee_complaint 结构
CREATE TABLE IF NOT EXISTS `isee_complaint` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `cus_name` varchar(30) NOT NULL COMMENT '投诉人',
  `policy_no` varchar(50) NOT NULL COMMENT '保单号',
  `cus_mobile` varchar(255) DEFAULT NULL COMMENT '投诉人联系电话',
  `complaint_detail` varchar(255) NOT NULL COMMENT '投诉原因',
  `product_code` varchar(20) DEFAULT NULL COMMENT '产品编码',
  `product_name` varchar(50) DEFAULT NULL COMMENT '产品名称',
  `complaint_status` varchar(10) DEFAULT NULL COMMENT '投诉状态',
  `processor` varchar(50) DEFAULT NULL COMMENT '操作人',
  `process_comments` varchar(255) DEFAULT NULL COMMENT '处理意见',
  `gmt_process` datetime DEFAULT NULL COMMENT '操作时间',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否逻辑删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客诉记录';



--  isee_00.isee_core_product 结构
CREATE TABLE IF NOT EXISTS `isee_core_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `core_campaign_id` varchar(50) DEFAULT NULL COMMENT '核心营销活动ID',
  `core_campaign_name` varchar(50) DEFAULT NULL COMMENT '核心营销名称',
  `core_package_id` varchar(50) DEFAULT NULL COMMENT '核心产品组合 ID',
  `core_package_name` varchar(50) DEFAULT NULL COMMENT '核心产品组合名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `org_no` varchar(50) DEFAULT NULL COMMENT '机构编码',
  `campaign_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `product_type` int(11) DEFAULT '2' COMMENT '产品类型',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uniq_ids` (`core_package_id`,`core_campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='核心产品信息表';



--  isee_00.isee_data_dictionary 结构
CREATE TABLE IF NOT EXISTS `isee_data_dictionary` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `type` varchar(20) NOT NULL COMMENT '字典类别编码',
  `type_name` varchar(30) NOT NULL COMMENT '字典类别描述',
  `code` varchar(20) NOT NULL COMMENT '编码',
  `code_value` varchar(60) NOT NULL COMMENT '编码值',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `creator` varchar(30) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改人',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '删除标识-Y:有效，N:无效',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uniq_type_code` (`type`,`code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='数据字典表';



--  isee_00.isee_function 结构
CREATE TABLE `isee_function`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `func_code` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '菜单编码',
  `func_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '菜单名称',
  `path` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '路径',
  `parent_func_id` bigint(20) UNSIGNED NOT NULL COMMENT '父级',
  `order` int(10) NULL DEFAULT NULL COMMENT '同级别顺序',
  `level` tinyint(4) NULL DEFAULT NULL COMMENT '级别、层级',
  `type` tinyint(4) NOT NULL COMMENT '1-菜单权限 2-按钮权限',
  `creator` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '创建者',
  `gmt_created` datetime(0) NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '修改者',
  `gmt_modified` datetime(0) NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已删除，N-正常',
  `api_path` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'api接口路径',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '菜单功能表' ROW_FORMAT = Dynamic;



--  isee_00.isee_hosts 结构
CREATE TABLE IF NOT EXISTS `isee_hosts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `host_name` varchar(50) NOT NULL COMMENT '域名名称',
  `host_code` varchar(50) NOT NULL COMMENT '域名代码',
  `host_url` varchar(200) NOT NULL COMMENT '域名url',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_url` (`host_url`),
  UNIQUE KEY `uniq_name` (`host_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='域名表';



--  isee_00.isee_page_def 结构
CREATE TABLE IF NOT EXISTS `isee_page_def` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `page_name` varchar(50) NOT NULL COMMENT '页面名称;',
  `page_code` varchar(50) NOT NULL COMMENT '页面代码',
  `host_code` varchar(50) NOT NULL COMMENT '关联域名代码',
  `page_url_regex` varchar(400) NOT NULL COMMENT '页面url匹配正则',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `page_type` char(1) NOT NULL COMMENT '产品类型 S-开始页面;E-结束页面;',
  `product_node_name` varchar(50) DEFAULT NULL COMMENT '产品节点名称',
  `is_product_node` tinyint(1) NOT NULL COMMENT '是否产品节点',
  `is_check_page` tinyint(1) NOT NULL COMMENT '是否质检页面',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `version` int(11) NOT NULL COMMENT '版本',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name_code` (`page_name`,`page_code`),
  UNIQUE KEY `uniq_name` (`page_name`),
  KEY `idx_p_code` (`page_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='回溯规则页面配置表';



--  isee_00.isee_policy_customer 结构
CREATE TABLE IF NOT EXISTS `isee_policy_customer` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(50) NOT NULL COMMENT '物理主键',
  `custom_type` char(1) NOT NULL COMMENT '客户类型1 投保人；2 被保人',
  `custom_name` varchar(50) DEFAULT NULL COMMENT '客户名称',
  `custom_id_type` char(3) DEFAULT NULL COMMENT '证件类型',
  `custom_id_no` varchar(50) DEFAULT NULL COMMENT '客户证件',
  `custom_mobile` varchar(20) DEFAULT NULL COMMENT '客户手机号',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `policy_id` bigint(20) DEFAULT NULL COMMENT 'video保单表id',
  PRIMARY KEY (`id`),
  KEY `idx_biz` (`biz_id`),
  KEY `idx_policy_id` (`policy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='客户信息表';



--  isee_00.isee_policy_extra_dic 结构
CREATE TABLE IF NOT EXISTS `isee_policy_extra_dic` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `extra_key` varchar(200) NOT NULL COMMENT '额外key',
  `query_mapping` varchar(50) DEFAULT NULL COMMENT '查询mapping，关联video查询',
  `description` varchar(200) DEFAULT NULL COMMENT '备注',
  `org_id` bigint(20) DEFAULT NULL COMMENT '机构ID',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `org_no` varchar(50) DEFAULT NULL COMMENT '机构编码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_org_key` (`org_no`,`extra_key`),
  KEY `idx_mapping` (`query_mapping`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='保单额外信息字典';



--  isee_00.isee_policy_extra_value 结构
CREATE TABLE IF NOT EXISTS `isee_policy_extra_value` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `org_id` bigint(20) DEFAULT NULL COMMENT '机构ID',
  `extra_key` varchar(200) NOT NULL COMMENT '额外key',
  `extra_value` varchar(200) NOT NULL COMMENT '额外值',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `org_no` varchar(50) DEFAULT NULL COMMENT '机构编码',
  `policy_id` bigint(20) DEFAULT NULL COMMENT 'video保单表id',
  PRIMARY KEY (`id`),
  KEY `idx_biz` (`biz_id`),
  KEY `idx_extra` (`extra_key`,`extra_value`),
  KEY `idx_policy_id` (`policy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='保单额外信息表';



--  isee_00.isee_process_def 结构
CREATE TABLE IF NOT EXISTS `isee_process_def` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `process_name` varchar(50) NOT NULL COMMENT '流程名称',
  `process_code` varchar(50) NOT NULL COMMENT '流程代码',
  `process_type` char(1) NOT NULL COMMENT '流程配置类型 C-通用;P-产品',
  `ref_type` char(2) NOT NULL COMMENT '业务回溯类别',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `version` int(11) NOT NULL COMMENT '版本',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `refresh_type` char(1) DEFAULT NULL COMMENT '刷新类型',
  `share_mode` char(1) DEFAULT 'N' COMMENT '分享类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name_code` (`process_name`,`process_code`),
  UNIQUE KEY `uniq_name` (`process_name`),
  KEY `idx_p_code` (`process_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='回溯规则流程配置表';



--  isee_00.isee_process_page 结构
CREATE TABLE IF NOT EXISTS `isee_process_page` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `page_code` varchar(50) NOT NULL COMMENT '页面配置代码',
  `process_code` varchar(50) NOT NULL COMMENT '流程配置代码',
  `order` int(11) NOT NULL COMMENT '页面顺序',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `refresh_type` char(1) DEFAULT NULL COMMENT '刷新类型',
  PRIMARY KEY (`id`),
  KEY `idx_p_p` (`process_code`,`page_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='回溯规则页面关联表';



--  isee_00.isee_product 结构
CREATE TABLE IF NOT EXISTS `isee_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `product_code` varchar(20) NOT NULL COMMENT '产品编码',
  `product_name` varchar(128) DEFAULT NULL COMMENT '产品名称',
  `agency_code` varchar(50) DEFAULT NULL COMMENT '机构代码',
  `agency_name` varchar(128) DEFAULT NULL COMMENT '机构名称',
  `product_type` tinyint(4) DEFAULT NULL COMMENT '长短险：1-长险；2-短险',
  `product_node_status` char(1) DEFAULT NULL COMMENT '产品节点配置状态： Y-已配置， N- 未配置',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` tinyint(1) DEFAULT NULL COMMENT '数据状态',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否逻辑删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='保险产品';



--  isee_00.isee_product_node 结构
CREATE TABLE IF NOT EXISTS `isee_product_node` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `product_code` varchar(30) NOT NULL COMMENT '产品编码',
  `order` int(4) DEFAULT NULL COMMENT '节点序号',
  `node_name` varchar(30) NOT NULL COMMENT '节点名称',
  `node_key` varchar(50) DEFAULT NULL COMMENT '节点Key',
  `node_value` varchar(500) DEFAULT NULL COMMENT '节点value',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否逻辑删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='产品节点';



--  isee_00.isee_quality 结构
CREATE TABLE IF NOT EXISTS `isee_quality` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `biz_id` varchar(45) DEFAULT NULL COMMENT '回溯码',
  `process_code` varchar(45) DEFAULT NULL COMMENT '回溯流程配置代码',
  `check_flag` char(1) DEFAULT NULL COMMENT '检查标记 N待检查 Y已检查',
  `success` char(1) DEFAULT NULL COMMENT '是否成功Y/N',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注',
  `creator` varchar(45) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(45) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '删除标记',
  PRIMARY KEY (`id`),
  KEY `idx_bizId_gmtModified` (`biz_id`,`gmt_modified`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='回溯质检清单';



--  isee_00.isee_quality_alarm 结构
CREATE TABLE IF NOT EXISTS `isee_quality_alarm` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `alarm_time` datetime DEFAULT NULL COMMENT '预警发生时间',
  `biz_id` varchar(50) DEFAULT NULL COMMENT '回溯码',
  `app_code` varchar(3) DEFAULT NULL COMMENT '应用代码',
  `level` int(11) DEFAULT NULL COMMENT '优先级',
  `alarm_type` varchar(2) DEFAULT NULL COMMENT '预警类型',
  `error_code` varchar(20) DEFAULT NULL COMMENT '错误码',
  `error_info` varchar(512) DEFAULT NULL COMMENT '错误码描述',
  `error_clz` varchar(2048) DEFAULT NULL COMMENT '预警打印执行类',
  `error_params` varchar(1024) DEFAULT NULL COMMENT '预警执行类的入参',
  `status` int(11) DEFAULT NULL COMMENT '状态',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  `creator` varchar(45) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(45) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '删除标记',
  PRIMARY KEY (`id`),
  KEY `idx_alarmTime_appCode` (`alarm_time`,`app_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='回溯视频预警明细';



--  isee_00.isee_quality_bug 结构
CREATE TABLE IF NOT EXISTS `isee_quality_bug` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `quality_id` bigint(20) DEFAULT NULL COMMENT 'isee_quality.id',
  `biz_id` varchar(45) DEFAULT NULL COMMENT '回溯码',
  `check_type` int(11) DEFAULT NULL COMMENT '1 视频大小 2视频时长 3业务字段完整性 4 关键节点检查',
  `status` int(11) DEFAULT NULL COMMENT '1 待确认 2 已确认待修复 3 已修复  4 误判,无需修复',
  `result` varchar(200) DEFAULT NULL COMMENT '检查结果',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  `creator` varchar(45) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(45) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '删除标记',
  PRIMARY KEY (`id`),
  KEY `idx_qualityId_bizId` (`quality_id`,`biz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='质检差异报表';



--  isee_00.isee_quality_manual 结构
CREATE TABLE IF NOT EXISTS `isee_quality_manual` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `task_date` datetime DEFAULT NULL COMMENT '任务生产日期',
  `agency_id` varchar(11) DEFAULT NULL COMMENT '机构编码',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `policy_no` varchar(128) DEFAULT NULL COMMENT '保单号',
  `product_code` varchar(20) DEFAULT NULL COMMENT '产品编码',
  `product_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `insured_name` varchar(128) DEFAULT NULL COMMENT '投保人姓名',
  `insured_cert_type` varchar(20) DEFAULT NULL COMMENT '证件类型',
  `insured_cert_no` varchar(40) DEFAULT NULL COMMENT '投保人证件号码',
  `insured_phone` varchar(20) DEFAULT NULL COMMENT '投保人电话',
  `problem_type` varchar(500) DEFAULT NULL COMMENT '问题类型，以逗号分隔开',
  `recheck_conclusion` varchar(500) DEFAULT NULL COMMENT '复检结论',
  `problem_desc` varchar(1000) DEFAULT NULL COMMENT '问题描述',
  `rechecked` tinyint(1) DEFAULT '0' COMMENT '是否已经复检',
  `recheck_date` datetime DEFAULT NULL COMMENT '质检时间',
  `checker_id` bigint(20) DEFAULT NULL COMMENT '质检人员ID',
  `checker_name` varchar(50) DEFAULT NULL COMMENT '质检人员姓名',
  `video_policy_id` bigint(20) DEFAULT NULL COMMENT '视频保单ID',
  `creator` varchar(45) DEFAULT NULL COMMENT '创建人',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` varchar(45) DEFAULT NULL COMMENT '更新人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '更新时间',
  `is_deleted` char(1) DEFAULT 'N' COMMENT '是否删除',
  `gmt_created_policy` datetime NOT NULL COMMENT '保单创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_biz_id` (`biz_id`),
  KEY `idx_policy_no` (`policy_no`),
  KEY `idx_agency_id` (`agency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='人工抽检任务表';



--  isee_00.isee_quality_rule 结构
CREATE TABLE IF NOT EXISTS `isee_quality_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `code` varchar(45) DEFAULT NULL COMMENT '等于回溯流程代码',
  `type` int(11) DEFAULT NULL COMMENT '1 视频时长  2视频大小  3业务字段 4节点检查',
  `rule` varchar(1024) DEFAULT NULL COMMENT '规则，JSON格式',
  `remark` varchar(256) DEFAULT NULL COMMENT '备注',
  `creator` varchar(45) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(45) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '删除标记',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='质检规则表';



--  isee_00.isee_quality_testing_item 结构
CREATE TABLE IF NOT EXISTS `isee_quality_testing_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `testing_date` datetime DEFAULT NULL COMMENT '质检日期',
  `agency_id` varchar(11) DEFAULT NULL COMMENT '机构编码',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `policy_no` varchar(128) DEFAULT NULL COMMENT '保单号',
  `product_code` varchar(20) DEFAULT NULL COMMENT '产品编码',
  `product_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `insured_name` varchar(128) DEFAULT NULL COMMENT '投保人姓名',
  `insured_cert_type` varchar(20) DEFAULT NULL COMMENT '证件类型',
  `insured_cert_no` varchar(40) DEFAULT NULL COMMENT '投保人证件号码',
  `insured_phone` varchar(20) DEFAULT NULL COMMENT '投保人电话',
  `priority` int(11) DEFAULT NULL COMMENT '优先级',
  `rules_id` varchar(128) DEFAULT NULL COMMENT '命中规则ID，以逗号分隔',
  `rules_desc` varchar(500) DEFAULT NULL COMMENT '命中规则描述，以逗号分隔',
  `problem_type` varchar(500) DEFAULT NULL COMMENT '问题类型，以逗号分隔开',
  `recheck_conclusion` varchar(500) DEFAULT NULL COMMENT '复检结论',
  `problem_desc` varchar(1000) DEFAULT NULL COMMENT '问题描述',
  `rechecked` tinyint(1) DEFAULT '0' COMMENT '是否已经复检',
  `creator` varchar(45) DEFAULT NULL COMMENT '创建人',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` varchar(45) DEFAULT NULL COMMENT '修改人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` char(1) DEFAULT 'N' COMMENT '是否删除',
  `video_id` bigint(20) DEFAULT NULL COMMENT '视频ID',
  PRIMARY KEY (`id`),
  KEY `idx_biz_id` (`biz_id`),
  KEY `idx_policy_no` (`policy_no`),
  KEY `idx_agency_id` (`agency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='自动质检详情表';



--  isee_00.isee_quality_testing_log 结构
CREATE TABLE IF NOT EXISTS `isee_quality_testing_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `biz_id` varchar(50) NOT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '状态0：质检未完成，1质检完成',
  `creator` varchar(45) DEFAULT NULL COMMENT '创建人',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` varchar(45) DEFAULT NULL COMMENT '修改人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` char(1) DEFAULT 'N' COMMENT '是否删除',
  `testing_passed` tinyint(1) DEFAULT NULL COMMENT '质检是否通过0:未通过, 1: 通过',
  PRIMARY KEY (`id`),
  KEY `idx_biz_id` (`biz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='自动质检记录表';



--  isee_00.isee_quality_testing_rule 结构
CREATE TABLE IF NOT EXISTS `isee_quality_testing_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL COMMENT '规则编码',
  `rule_name` varchar(100) DEFAULT NULL COMMENT '规则名称',
  `rule_desc` varchar(100) DEFAULT NULL COMMENT '规则描述',
  `priority` int(11) DEFAULT NULL COMMENT '优先级',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态0：关闭，1开启',
  `creator` varchar(45) DEFAULT NULL COMMENT '创建人',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` varchar(45) DEFAULT NULL COMMENT '修改人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` char(1) DEFAULT 'N' COMMENT '是否删除',
  `params` varchar(1000) DEFAULT NULL COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='自动质检规则表';



--  isee_00.isee_quality_testing_statement 结构
CREATE TABLE IF NOT EXISTS `isee_quality_testing_statement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `testing_date` datetime DEFAULT NULL COMMENT '质检日期',
  `agency_id` varchar(100) DEFAULT NULL COMMENT '机构ID',
  `passed_qty` int(11) DEFAULT NULL COMMENT '质检合格数量',
  `unpassed_qty` int(11) DEFAULT NULL COMMENT '质检部合格数量',
  `creator` varchar(45) DEFAULT NULL COMMENT '创建人',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` varchar(45) DEFAULT NULL COMMENT '修改人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` char(1) DEFAULT 'N' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `idx_agency_id` (`agency_id`),
  KEY `idx_testing_date` (`testing_date`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='自动质检报表表';



--  isee_00.isee_quality_unnormal 结构
CREATE TABLE IF NOT EXISTS `isee_quality_unnormal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `count_date` datetime DEFAULT NULL COMMENT '统计日期',
  `agency_id` varchar(11) DEFAULT NULL COMMENT '机构编码',
  `source` varchar(200) NOT NULL COMMENT '异常数据来源',
  `rules_id` varchar(128) DEFAULT NULL COMMENT '命中规则ID，以逗号分隔',
  `rules_desc` varchar(500) DEFAULT NULL COMMENT '命中规则描述，以逗号分隔',
  `problem_type` varchar(500) DEFAULT NULL COMMENT '问题类型，以逗号分隔开',
  `problem_desc` varchar(1000) DEFAULT NULL COMMENT '问题描述',
  `biz_id` varchar(200) DEFAULT NULL,
  `policy_no` varchar(128) DEFAULT NULL COMMENT '保单号',
  `product_code` varchar(20) DEFAULT NULL COMMENT '产品编码',
  `product_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `insured_name` varchar(128) DEFAULT NULL COMMENT '投保人姓名',
  `insured_cert_type` varchar(20) DEFAULT NULL COMMENT '证件类型',
  `insured_cert_no` varchar(40) DEFAULT NULL COMMENT '投保人证件号码',
  `insured_phone` varchar(20) DEFAULT NULL COMMENT '投保人电话',
  `creator` varchar(45) DEFAULT NULL COMMENT '创建人',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `modifier` varchar(45) DEFAULT NULL COMMENT '更新人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '更新时间',
  `is_deleted` char(1) DEFAULT 'N' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `idx_biz_id` (`biz_id`),
  KEY `idx_policy_no` (`policy_no`),
  KEY `idx_agency_id` (`agency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='回溯异常管理表';



--  isee_00.isee_reconciliation_data 结构
CREATE TABLE IF NOT EXISTS `isee_reconciliation_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `reconc_date` date NOT NULL COMMENT '对账日期',
  `reconc_serial` varchar(200) NOT NULL COMMENT '对账批次号',
  `org_no` varchar(50) NOT NULL COMMENT '机构编码',
  `trans_time` datetime NOT NULL COMMENT '交易时间',
  `trans_id` varchar(200) NOT NULL COMMENT '业务唯一标识',
  `biz_id` varchar(200) DEFAULT NULL COMMENT '千里眼业务回溯码',
  `policy_no` varchar(200) DEFAULT NULL COMMENT '保单号',
  `reconc_flag` char(1) DEFAULT NULL COMMENT '对账结果 S-成功,F-失败',
  `reconc_fail_reason` char(2) DEFAULT NULL COMMENT '失败原因 枚举类',
  `exclude_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否排除 默认否',
  `creator` varchar(50) NOT NULL DEFAULT 'system' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'system' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_reconcdate_orgno_` (`reconc_date`,`org_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='对账数据表';



--  isee_00.isee_reconciliation_diff 结构
CREATE TABLE IF NOT EXISTS `isee_reconciliation_diff` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `reconc_date` date NOT NULL COMMENT '对账日期',
  `reconc_serial` varchar(200) NOT NULL COMMENT '对账批次号',
  `org_no` varchar(50) NOT NULL COMMENT '机构编码',
  `trans_time` datetime NOT NULL COMMENT '交易时间，如保单出单时间',
  `trans_id` varchar(200) NOT NULL COMMENT '业务唯一标识',
  `biz_id` varchar(200) DEFAULT NULL COMMENT '千里眼业务回溯码',
  `policy_no` varchar(200) DEFAULT NULL COMMENT '保单号',
  `product_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `holder_name` varchar(128) DEFAULT NULL COMMENT '投保人姓名',
  `holder_cert_no` varchar(40) DEFAULT NULL COMMENT '投保人证件号码',
  `holder_mobile` varchar(20) DEFAULT NULL COMMENT '投保人手机号',
  `reconc_flag` char(1) DEFAULT NULL COMMENT '对账结果 S-成功,F-失败',
  `reconc_fail_reason` char(2) DEFAULT NULL COMMENT '失败原因 枚举类',
  `review_status` char(1) DEFAULT NULL COMMENT '差异处理结果',
  `review_comment` varchar(200) DEFAULT NULL COMMENT '差异处理备注',
  `creator` varchar(50) NOT NULL DEFAULT 'system' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'system' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_bid` (`biz_id`),
  KEY `idx_trans_id` (`trans_id`),
  KEY `idx_policy_no` (`policy_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='对账数据表';



--  isee_00.isee_reconciliation_notify 结构
CREATE TABLE IF NOT EXISTS `isee_reconciliation_notify` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `reconc_date` date NOT NULL COMMENT '对账日期',
  `org_no` varchar(50) NOT NULL COMMENT '机构编码',
  `reconc_count` int(10) NOT NULL COMMENT '对账批次数据条数',
  `reconc_status` char(1) DEFAULT NULL COMMENT '对账状态 0-未对账 1-对账失败 2-对账完成',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注，如对账失败原因等',
  `creator` varchar(50) NOT NULL DEFAULT 'system' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'system' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_reconcdate_orgno_` (`reconc_date`,`org_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='对账通知表';



--  isee_00.isee_reconciliation_store 结构
CREATE TABLE IF NOT EXISTS `isee_reconciliation_store` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `reconc_date` date NOT NULL COMMENT '对账日期',
  `org_no` varchar(50) NOT NULL COMMENT '机构编码',
  `trans_time` datetime NOT NULL COMMENT '交易时间，如保单出单时间',
  `trans_id` varchar(200) NOT NULL COMMENT '业务唯一标识',
  `biz_id` varchar(200) DEFAULT NULL COMMENT '千里眼业务回溯码',
  `policy_no` varchar(200) DEFAULT NULL COMMENT '保单号',
  `creator` varchar(50) NOT NULL DEFAULT 'system' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'system' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_reconcdate_orgno_` (`reconc_date`,`org_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='对账数据临时存放表';



--  isee_00.isee_reconciliation_total 结构
CREATE TABLE IF NOT EXISTS `isee_reconciliation_total` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `reconc_date` date NOT NULL COMMENT '对账日期',
  `reconc_serial` varchar(200) NOT NULL COMMENT '对账批次号',
  `org_no` varchar(50) NOT NULL COMMENT '机构编码',
  `reconc_count` int(11) NOT NULL DEFAULT '0' COMMENT '对账总数',
  `reconc_success` int(11) NOT NULL DEFAULT '0' COMMENT '对账成功数',
  `reconc_fail` int(11) NOT NULL DEFAULT '0' COMMENT '对账失败数',
  `reconc_batch_status` char(1) NOT NULL DEFAULT '0' COMMENT '对账处理状态 0-未开始 1-处理中 2-处理完成',
  `creator` varchar(50) NOT NULL DEFAULT 'system' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'system' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `remark` varchar(1000) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='对账数据表';



--  isee_00.isee_record_channel 结构
CREATE TABLE IF NOT EXISTS `isee_record_channel` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `channel_code` varchar(50) DEFAULT NULL COMMENT '渠道编码',
  `channel_name` varchar(50) DEFAULT NULL COMMENT '渠道名称',
  `platform` varchar(50) DEFAULT NULL COMMENT '操作系统平台',
  `domain` varchar(50) DEFAULT NULL COMMENT '域名',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='视频录制渠道表';



--  isee_00.isee_record_scenario 结构
CREATE TABLE IF NOT EXISTS `isee_record_scenario` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `url_sno` varchar(50) DEFAULT NULL COMMENT '访问地址编号',
  `domain` varchar(50) DEFAULT NULL COMMENT '访问地址域名',
  `url_reg` varchar(255) DEFAULT NULL COMMENT '页面访问正则',
  `url_type` varchar(10) DEFAULT NULL COMMENT '页面类型',
  `url_desc` varchar(100) DEFAULT NULL COMMENT '描述',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='视频录制配置信息';



--  isee_00.isee_replay_data 结构
CREATE TABLE IF NOT EXISTS `isee_replay_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `oss_key` varchar(50) DEFAULT NULL COMMENT 'ossKey',
  `url` varchar(500) DEFAULT NULL COMMENT 'oss地址',
  `origin` varchar(20) DEFAULT '0' COMMENT ' 数据来源',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `video_end_time` datetime DEFAULT NULL COMMENT '视频截止时间',
  `data_type` char(1) DEFAULT 'V' COMMENT 'V-video 视频,T-trace 轨迹',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_biz` (`biz_id`),
  KEY `idx_gmt_created` (`gmt_created`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='视频回放原始报文表';



--  isee_00.isee_resource 结构
CREATE TABLE IF NOT EXISTS `isee_resource` (
  `id` bigint(20) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `version` bigint(20) unsigned DEFAULT NULL COMMENT '版本',
  `url` varchar(2048) DEFAULT NULL COMMENT 'url',
  `hash` varchar(500) DEFAULT NULL COMMENT '文件hash',
  `path` varchar(500) DEFAULT NULL COMMENT '文件存放路径',
  `creator` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`),
  KEY `idx_url` (`url`(255)),
  KEY `idx_hash` (`hash`(255)),
  KEY `idx_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='静态资源表';



--  isee_00.isee_role 结构
CREATE TABLE IF NOT EXISTS `isee_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `role_name` varchar(50) NOT NULL COMMENT '角色名称',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '授权时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='角色表';



--  isee_00.isee_role_func 结构
CREATE TABLE IF NOT EXISTS `isee_role_func` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `func_code` varchar(50) NOT NULL COMMENT '菜单编号',
  `role_id` bigint(20) unsigned NOT NULL COMMENT '角色编号(isee_role物理主键)',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='角色-功能关联表';



--  isee_00.isee_role_user 结构
CREATE TABLE IF NOT EXISTS `isee_role_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `uid` bigint(20) NOT NULL COMMENT '用户编号',
  `role_id` bigint(20) NOT NULL COMMENT '角色编号',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='角色-账户关联表';



--  isee_00.isee_stats_daily 结构
CREATE TABLE IF NOT EXISTS `isee_stats_daily` (
  `id` bigint(20) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `type` varchar(10) NOT NULL COMMENT '报表类型',
  `channel_name` varchar(100) DEFAULT NULL COMMENT '渠道名称',
  `report_date` varchar(10) DEFAULT NULL COMMENT '统计日期:yyyy-MM-dd',
  `value` bigint(20) DEFAULT '0' COMMENT '报表值',
  `creator` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='每日分渠道报表';



--  isee_00.isee_system_config 结构
CREATE TABLE IF NOT EXISTS `isee_system_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `param_name` varchar(200) NOT NULL COMMENT '参数名称',
  `property_key` varchar(50) NOT NULL COMMENT '属性key',
  `property_value` varchar(255) NOT NULL COMMENT '属性值',
  `remark` varchar(200) DEFAULT NULL COMMENT '配置项描述',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '修建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uniq_property_type_property_key` (`property_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统配置表';



--  isee_00.isee_user 结构
CREATE TABLE IF NOT EXISTS `isee_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `agency_code` varchar(50) DEFAULT NULL COMMENT '机构代码(机构表agency_code)',
  `agency_name` varchar(50) DEFAULT NULL COMMENT '机构名称',
  `user_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `name_pinyin` varchar(50) DEFAULT NULL COMMENT '用户姓名对应的拼音',
  `login_name` varchar(50) NOT NULL COMMENT '用户登录名',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `certi_type` varchar(5) DEFAULT NULL COMMENT '证件类型',
  `certi_no` varchar(50) DEFAULT NULL COMMENT '证件号码',
  `mobile` varchar(50) DEFAULT NULL COMMENT '手机号',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱地址',
  `address` varchar(128) DEFAULT NULL COMMENT '联系地址',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `status` char(1) DEFAULT NULL COMMENT '枚举，0有效，1无效',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='用户表';



--  isee_00.isee_video 结构
CREATE TABLE IF NOT EXISTS `isee_video` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `video_key` varchar(200) DEFAULT NULL COMMENT '视频唯一标识',
  `video_no` varchar(50) NOT NULL COMMENT '视频编号',
  `node_list` varchar(2000) DEFAULT NULL COMMENT '视频节点列表信息',
  `policy_no` varchar(128) DEFAULT NULL COMMENT '视频关联保单号',
  `video_length` varchar(20) DEFAULT NULL COMMENT '视频时长',
  `video_size` bigint(20) DEFAULT '0' COMMENT '视频大小',
  `sale_channel` varchar(20) DEFAULT '未知' COMMENT '销售渠道',
  `video_width` varchar(20) DEFAULT NULL COMMENT '视频宽度',
  `video_height` varchar(20) DEFAULT NULL COMMENT '视频高度',
  `platform` varchar(20) DEFAULT NULL COMMENT '用户操作平台',
  `video_url` varchar(1000) DEFAULT NULL COMMENT '视频地址',
  `operating_platform` varchar(1000) DEFAULT NULL COMMENT '客户操作平台',
  `summary_code` varchar(50) DEFAULT NULL COMMENT '视频摘要编码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `parent_biz_id` varchar(200) DEFAULT NULL COMMENT '所属主bizId',
  `video_start_time` bigint(20) DEFAULT NULL COMMENT '视频开始时间戳',
  `process_code` varchar(50) DEFAULT NULL COMMENT '流程编码',
  PRIMARY KEY (`id`),
  KEY `idx_biz` (`biz_id`),
  KEY `idx_parent_biz_id` (`parent_biz_id`),
  KEY `idx_gmt_created` (`gmt_created`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='跟踪视频信息表';



--  isee_00.isee_video_download_apply 结构
CREATE TABLE IF NOT EXISTS `isee_video_download_apply` (
  `id` bigint(20) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `channel_id` bigint(20) DEFAULT NULL COMMENT '渠道编号-冗余',
  `order_no` varchar(200) DEFAULT NULL COMMENT '订单编号-冗余',
  `policy_no` varchar(128) DEFAULT NULL COMMENT '保单号-冗余',
  `insured_name` varchar(128) DEFAULT NULL COMMENT '投保人姓名-冗余',
  `insured_cert_no` varchar(40) DEFAULT NULL COMMENT '投保人证件号码-冗余',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `apply_time` datetime DEFAULT NULL COMMENT '申请时间',
  `apply_status` char(1) DEFAULT NULL COMMENT '处理状态 W-未处理 R-处理中 F-已完成',
  `finish_time` datetime DEFAULT NULL COMMENT '完成时间',
  `apply_user` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '申请人',
  `creator` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '创建人',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL DEFAULT 'admin' COMMENT '修改人',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`),
  KEY `idx_biz` (`biz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='视频下载申请表';



--  isee_00.isee_video_log 结构
CREATE TABLE IF NOT EXISTS `isee_video_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `gmt_visit` datetime DEFAULT NULL COMMENT '访问时间',
  `page_url` varchar(2048) DEFAULT NULL COMMENT '页面访问地址',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`),
  KEY `IDX_BIZID` (`biz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='视频访问日志表';



--  isee_00.isee_video_policy 结构
CREATE TABLE IF NOT EXISTS `isee_video_policy` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `order_no` varchar(200) DEFAULT NULL COMMENT '订单编号',
  `product_code` varchar(20) DEFAULT NULL COMMENT '产品编码',
  `product_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `policy_no` varchar(128) DEFAULT NULL COMMENT '保单号',
  `insured_name` varchar(128) DEFAULT NULL COMMENT '投保人姓名',
  `insured_cert_type` varchar(20) DEFAULT NULL COMMENT '证件类型',
  `insured_cert_no` varchar(40) DEFAULT NULL COMMENT '投保人证件号码',
  `insured_phone` varchar(20) DEFAULT NULL COMMENT '投保人电话',
  `apply_time` datetime DEFAULT NULL COMMENT '投保时间',
  `underwriting_time` datetime DEFAULT NULL COMMENT '承保时间',
  `sale_channel` varchar(50) DEFAULT NULL COMMENT '销售渠道',
  `gmt_archive` datetime DEFAULT NULL COMMENT '归档时间',
  `gmt_destroy` datetime DEFAULT NULL COMMENT '销毁时间',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `channel_id` bigint(20) DEFAULT NULL COMMENT '渠道编号',
  `marketing_code` varchar(30) DEFAULT NULL COMMENT '营销编号',
  `can_replay` tinyint(1) DEFAULT '0' COMMENT '是否已经可以回溯',
  `org_no` varchar(50) DEFAULT NULL COMMENT '机构编码',
  `channel_name` varchar(128) DEFAULT NULL COMMENT '业务渠道名称',
  `channel_no` varchar(128) DEFAULT NULL COMMENT '业务渠道代码',
  `gmt_video` datetime DEFAULT NULL COMMENT '视频生成时间',
  `company_name` varchar(100) DEFAULT NULL COMMENT '保险公司名称',
  `data_type` char(1) DEFAULT 'V' COMMENT 'V-video 视频,T-trace 轨迹',
  PRIMARY KEY (`id`),
  KEY `idx_gmt_video` (`gmt_video`),
  KEY `idx_biz` (`biz_id`),
  KEY `idx_orderNo` (`order_no`),
  KEY `idx_GmtArchiveGmtCreated` (`gmt_archive`,`gmt_created`),
  KEY `idx_PolicyNo` (`policy_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='视频对应保单表';



--  isee_00.isee_video_record 结构
CREATE TABLE IF NOT EXISTS `isee_video_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(200) NOT NULL COMMENT '业务跟踪ID',
  `video_no` varchar(50) DEFAULT NULL COMMENT '视频编号',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `gmt_destroy` datetime DEFAULT NULL COMMENT '销毁时间',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '归档时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='跟踪视频归档信息表';

--  isee_00.isee_video_record_apply 结构
CREATE TABLE IF NOT EXISTS `isee_video_record_apply` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `uid` bigint(20) unsigned NOT NULL COMMENT '申请人用户编号',
  `policy_no` varchar(50) NOT NULL COMMENT '保单号',
  `reason` varchar(50) NOT NULL COMMENT '申请原因',
  `auditor` varchar(50) DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `audit_comments` varchar(255) DEFAULT NULL COMMENT '审核意见',
  `review_status` char(1) DEFAULT '1' COMMENT '审核状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='调档申请表';

--  isee_00.isee_video_validation 结构
CREATE TABLE IF NOT EXISTS `isee_video_validation` (
  `id` bigint(20) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `uid` bigint(20) unsigned DEFAULT NULL COMMENT '用户编号',
  `policy_no` varchar(50) DEFAULT NULL COMMENT '保单号',
  `valation_video_url` varchar(255) DEFAULT NULL COMMENT '待验证视频URL',
  `validion_video_summary` varchar(255) DEFAULT NULL COMMENT '待验证视频摘要',
  `validate_result` varchar(10) DEFAULT NULL COMMENT '视频验证结果',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='视频验证表';

--  isee_00.isee_insure_fllow 结构
CREATE TABLE `isee_insure_fllow` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `product_name` varchar(100) DEFAULT NULL COMMENT '产品名称',
  `vsersion` varchar(100) NOT NULL COMMENT '版本号',
  `page_count` int(11) NOT NULL DEFAULT '0' COMMENT '页面数量',
  `gmt_valid_start` datetime NOT NULL COMMENT '有效期开始时间',
  `gmt_valid_end` datetime DEFAULT NULL COMMENT '有效期结束时间',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_product_name_version` (`product_name`,`vsersion`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='投保流程';


--  isee_00.isee_photo_gallery 结构
CREATE TABLE `isee_photo_gallery` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `name` varchar(100) DEFAULT NULL COMMENT '图片名称',
  `address` varchar(500) NOT NULL COMMENT '图片地址',
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `sign` varchar(1000) DEFAULT NULL COMMENT '图片摘要',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='图片库';


--  isee_00.isee_insure_page 结构
CREATE TABLE `isee_insure_page` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `insure_fllow_id` bigint(20) unsigned NOT NULL COMMENT '投保流程ID',
  `page_name` varchar(500) DEFAULT NULL COMMENT '页面名称',
  `sequence` int(11) DEFAULT NULL COMMENT '顺序',
  `code` varchar(100) DEFAULT NULL COMMENT '编码',
  `photo_address` varchar(6000) DEFAULT NULL,
  `creator` varchar(50) NOT NULL COMMENT '创建者',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改者',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='投保流程页面';


-- isee_report_trace 结构
CREATE TABLE `isee_report_trace` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '物理主键',
  `biz_id` varchar(200) NOT NULL COMMENT '业务回溯码',
  `trace_key` varchar(200) DEFAULT NULL COMMENT 'trace唯一标识',
  `trace_no` varchar(50) NOT NULL COMMENT 'trace编号',
  `policy_no` varchar(128) DEFAULT NULL COMMENT '关联保单号',
  `trace_length` varchar(20) DEFAULT NULL COMMENT 'trace时长',
  `sale_channel` varchar(20) DEFAULT '未知' COMMENT '销售渠道',
  `platform` varchar(20) DEFAULT NULL COMMENT '用户操作平台',
  `trace_url` varchar(1000) DEFAULT NULL COMMENT '记录地址',
  `summary_code` varchar(50) DEFAULT NULL COMMENT '摘要编码',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `status` char(1) DEFAULT NULL COMMENT '数据状态',
  `creator` varchar(50) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '视频生成时间',
  `modifier` varchar(50) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT '是否删除，Y-已经删除，N-正常',
  `parent_biz_id` varchar(200) DEFAULT NULL COMMENT '父级回溯码',
  PRIMARY KEY (`id`),
  KEY `idx_biz_id` (`biz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='上报追踪信息表';
