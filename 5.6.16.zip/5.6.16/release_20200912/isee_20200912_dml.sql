#填充默认数据
update isee_video_policy set can_replay = 1 where data_type = 'T';
#更新规则校验参数
update isee_quality_testing_rule set params = '1209600000' where code ='ISEE_BIZ_AGING';
update isee_quality_testing_rule set params = '1200000' where code ='VIDEO_DURATION_MAX';
update isee_quality_testing_rule set params = '3000' where code ='VIDEO_DURATION_MIN';