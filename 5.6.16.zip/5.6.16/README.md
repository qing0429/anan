# sql执行顺序
* release0912版本：isee_init_ddl.sql-->3.1update里isee_00.DDL.sql-->isee_init_dml.sql
-->3.1update里isee_00.DML.sql-->isee_release_20200912_ddl.sql-->isee_20200912_dml.sql