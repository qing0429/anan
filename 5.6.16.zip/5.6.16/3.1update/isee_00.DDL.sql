-- 新环境执行此行不需要执行
-- alter table isee_function ADD `api_path` VARCHAR(1024) DEFAULT NULL COMMENT '接口权限列表';

alter table isee_system_config modify column property_value varchar(1024) not null comment '属性值';

ALTER TABLE isee_photo_gallery ADD vsersion varchar(100) NULL COMMENT '版本号';
ALTER TABLE isee_insure_fllow ADD video_address varchar(6000) NULL COMMENT '视频地址';
ALTER TABLE isee_insure_fllow ADD enclosure_address varchar(6000) NULL COMMENT '附件地址';


ALTER TABLE isee_insure_fllow ADD open_snapshot TINYINT(1) DEFAULT 1 COMMENT '是否开启截图';
ALTER TABLE isee_insure_fllow ADD gmt_last_operation datetime  NOT NULL COMMENT '上次操作时间';

-- 删除唯一约束
ALTER TABLE isee_insure_fllow DROP INDEX idx_product_name_version;


ALTER TABLE isee_video_policy MODIFY COLUMN insured_cert_no varchar(500) NULL COMMENT '投保人证件号码';
ALTER TABLE isee_policy_customer MODIFY COLUMN custom_id_no varchar(500) NULL COMMENT '客户证件';
ALTER TABLE isee_video_policy MODIFY COLUMN insured_phone varchar(500) NULL COMMENT '投保人电话';
ALTER TABLE isee_policy_customer MODIFY COLUMN custom_mobile varchar(500) NULL COMMENT '客户手机号';
ALTER TABLE isee_reconciliation_diff MODIFY COLUMN holder_name varchar(500) NULL COMMENT '投保人姓名';
ALTER TABLE isee_reconciliation_diff MODIFY COLUMN holder_cert_no varchar(500) NULL COMMENT '投保人证件号码';
ALTER TABLE isee_reconciliation_diff MODIFY COLUMN holder_mobile varchar(500) NULL COMMENT '投保人手机号';
ALTER TABLE isee_reconciliation_data MODIFY COLUMN policy_no varchar(500) NULL COMMENT '保单号';
ALTER TABLE isee_quality_manual MODIFY COLUMN insured_name varchar(500) NULL COMMENT '投保人姓名';
ALTER TABLE isee_quality_manual MODIFY COLUMN insured_cert_no varchar(500) NULL COMMENT '投保人证件号码';
ALTER TABLE isee_quality_manual MODIFY COLUMN insured_phone varchar(500) NULL COMMENT '投保人电话';
ALTER TABLE isee_video_download_apply MODIFY COLUMN order_no varchar(500) NULL COMMENT '订单编号-冗余';
ALTER TABLE isee_video_download_apply MODIFY COLUMN policy_no varchar(500) NULL COMMENT '保单号-冗余';
ALTER TABLE isee_video_download_apply MODIFY COLUMN insured_name varchar(500) NULL COMMENT '投保人姓名-冗余';
ALTER TABLE isee_video_download_apply MODIFY COLUMN insured_cert_no varchar(500) NULL COMMENT '投保人证件号码-冗余';
ALTER TABLE isee_complaint MODIFY COLUMN policy_no varchar(500) NOT NULL COMMENT '保单号';
ALTER TABLE isee_complaint MODIFY COLUMN cus_mobile varchar(500) NULL COMMENT '投诉人联系电话';
ALTER TABLE isee_complaint MODIFY COLUMN cus_name varchar(500) NOT NULL COMMENT '投诉人';

ALTER TABLE isee_quality_testing_item MODIFY COLUMN policy_no varchar(200) NULL COMMENT '保单号';
ALTER TABLE isee_quality_testing_item MODIFY COLUMN insured_name varchar(500) NULL COMMENT '投保人姓名';
ALTER TABLE isee_quality_testing_item MODIFY COLUMN insured_cert_no varchar(500) NULL COMMENT '投保人证件号码';
ALTER TABLE isee_quality_testing_item MODIFY COLUMN insured_phone varchar(500) NULL COMMENT '投保人电话';
ALTER TABLE isee_quality_unnormal MODIFY COLUMN policy_no varchar(200) NULL COMMENT '保单号';
ALTER TABLE isee_quality_unnormal MODIFY COLUMN insured_name varchar(500) NULL COMMENT '投保人姓名';
ALTER TABLE isee_quality_unnormal MODIFY COLUMN insured_cert_no varchar(500) NULL COMMENT '投保人证件号码';
ALTER TABLE isee_quality_unnormal MODIFY COLUMN insured_phone varchar(500) NULL COMMENT '投保人电话';

ALTER TABLE isee_video_record_apply MODIFY COLUMN policy_no varchar(500) NOT NULL COMMENT '保单号';
ALTER TABLE isee_video_validation MODIFY COLUMN policy_no varchar(500) NULL COMMENT '保单号';







-- 修改osskey长度
ALTER TABLE isee_replay_data MODIFY COLUMN oss_key VARCHAR(200) COMMENT '对象存储地址';
