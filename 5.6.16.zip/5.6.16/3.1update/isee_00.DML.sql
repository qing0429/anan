update isee_function set api_path='/function/sub,/agency/load,/video/query,/video/detailNew,/video/log/list,/serverconfig.json,/user/info,/user/auth,/common/queryDictionary,/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply,/video/apply/query,/video/extraPair' where func_code='M000021';
update isee_function set api_path='/function/sub,/gallery/photo/list/page,/insure/flow/page/list,/gallery/photo/batch/upload,/insure/flow/add,/insure/page/add,/insure/flow/delete,/insure/flow/snapshotOperation,/insure/flow/queryByVersion,/insure/flow/file/upload,/insure/flow/file/add,/insure/flow/file/delete,/gallery/photo/delete,/insure/page/update,/insure/page/delete' where func_code='M000151';
update isee_function set api_path='/function/sub,/agency/load,/video/query,/trace/log,/insure/page/code' where func_code='M000152';
update isee_function set api_path='/function/sub,/report/video/total,/report/video/channel,/report/video/channel/daily,/report/video/top' where func_code='M000091';
update isee_function set api_path='/function/sub,/report/analysis/total,/report/analysis/channel,/report/analysis/channel/daily,/report/analysis/translet' where func_code='M000092';
update isee_function set api_path='/function/sub,/reconc/total,/agency/load,/reconc/downloadDetail/{reconcSerial},/reconc/downloadTotal,/reconc/remark,/reconc/repair/{reconcSerial}/{type},' where func_code='M000111';
update isee_function set api_path='/function/sub,/reconc/diffReport,/agency/load,/reconc/diff,/reconc/reviewDiff,/reconc/downloadDiff' where func_code='M000112';
update isee_function set api_path='/function/sub,/quality/testing/rule/list,/quality/testing/rule/change/state' where func_code='M000121';
update isee_function set api_path='/function/sub,/agency/load,/quality/testing/statement/list,/quality/testing/statement/list/download' where func_code='M000122';
update isee_function set api_path='/function/sub,/quality/testing/rule/list,/agency/load,/quality/testing/item/list,/quality/testing/item/{id},/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply,/quality/testing/item/recheck,/quality/testing/item/list/download' where func_code='M000123';
update isee_function set api_path='/function/sub,/quality/testing/rule/list,/agency/load,/quality/manual/list,/coreProduct/list,/quality/manual/random/rule/query,/quality/manual/random/rule,/quality/manual/detail/{id},/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply,/quality/manual/recheck,/quality/manual/download,/quality/manual/directional/extract' where func_code='M000125';
update isee_function set api_path='/function/sub,/agency/load,/quality/unnormal/list,/quality/unnormal/download' where func_code='M000131';
update isee_function set api_path='/function/sub,/complaint/query,/complaint/addOrProcess,/video/policy/query,/video/detailNew,/system/config/queryByCondition,/video/detailListNew,/replay/query/{iseeBiz},/api/reference/info,/api/reference/content,/video/download/apply' where func_code='M000031';
update isee_function set api_path='/function/sub,/video/apply/query,/video/download/stream' where func_code='M000061';
update isee_function set api_path='/function/sub,/video/validation/list,/video/validate' where func_code='M000041';
update isee_function set api_path='/function/sub,/archive/query,/archive/apply' where func_code='M000051';
update isee_function set api_path='/function/sub,/archive/apply/mine' where func_code='M000052';
update isee_function set api_path='/function/sub,/archive/apply/queryAll,/archive/apply/audit' where func_code='M000053';
update isee_function set api_path='/function/sub,/hosts/list,/page/list,/page' where func_code='M000077';
update isee_function set api_path='/function/sub,/processRef,/page/all,/hosts/list,/process/list,/processCheck,/process,/process/{processCode}' where func_code='M000078';
update isee_function set api_path='/function/sub,/agency/load,/coreProduct/list' where func_code='M000011';
update isee_function set api_path='/function/sub,/agency/load,/agency/upload,/agency/query,/agency/add' where func_code='M000071';
update isee_function set api_path='/function/sub,/hosts/query,/hosts' where func_code='M000078' and func_name='域名管理';
update isee_function set api_path='/function/sub,/agency/load,/user/query,/user/add,/user/reset/password,/user/delete' where func_code='M000081';
update isee_function set api_path='/function/sub,/role/list,/role/save,/role/delete' where func_code='M000082';
update isee_function set api_path='/function/sub,/role/list,/role/user/detail,/role/user/save,/role/func/detail,/role/func/save,' where func_code='M000083';
update isee_function set api_path='/function/sub,/agency/load,/agency/auth/list,/agency/auth/save,/agency/auth/delete' where func_code='M000084';
update isee_function set api_path='/function/sub,/data/dict/query,/data/dict/addOrUpdate,/data/dict/delete' where func_code='M000073';
update isee_function set api_path='/function/sub,/system/config/query,/system/config/queryByCondition,/system/config/addOrUpdate' where func_code='M000074';
update isee_function set api_path='/function/sub,/audit/list' where func_code='M000085';

-- 与init_ddl里func_code保持一致（以init_ddl里的func_code为准）
update isee_function set api_path='/function/sub,/hosts/list,/page/list,/page' where func_code='M000076';
update isee_function set api_path='/function/sub,/processRef,/page/all,/hosts/list,/process/list,/processCheck,/process,/process/{processCode}' where func_code='M000077';
update isee_function set api_path='/function/sub,/hosts/query,/hosts' where func_code='M000078';


-- 菜单调整
-- 新增一级菜单“回溯数据采集”
update isee_function set is_deleted='Y' where func_code='M00002';
insert into isee_function (func_code,func_name,`path`,parent_func_id,`order`,`level`,`type`,
creator,gmt_created,modifier,gmt_modified,is_deleted) values ('M000153','回溯数据采集','/',0,1,1,1,
'admin',now(),'admin',now(),'N');

update isee_function set func_name='视频回溯管理',modifier='admin',gmt_modified=now(),
parent_func_id=(select a.id from (select id from isee_function where func_code='M000153' limit 1) a) 
where func_code='M000021';

update isee_function set func_name='操作轨迹管理',modifier='admin',gmt_modified=now(),parent_func_id=
(select a.id from (select id from isee_function where func_code='M000153' limit 1) a)
where func_code='M000152';


-- “版本管理”升级为一级菜单
update isee_function set is_deleted='Y',gmt_modified=now() where func_code='M00015';
insert into isee_function (func_code,func_name,`path`,parent_func_id,`order`,`level`,`type`,
creator,gmt_created,modifier,gmt_modified,is_deleted) values ('M000155','版本管理','/rootVersion',0,1,1,1,
'admin',now(),'admin',now(),'N');
update isee_function set parent_func_id=(select t.id from (select id from isee_function where func_code='M000155' limit 1) t),
`order`=1,`level`=2,modifier='admin',gmt_modified=now() where func_code='M000151';

-- 新增一级菜单“权限管理”
insert into isee_function (func_code,func_name,`path`,parent_func_id,`order`,`level`,`type`,
creator,gmt_created,modifier,gmt_modified,is_deleted) values ('M000154','权限管理','/powerManage',0,1,1,1,
'admin',now(),'admin',now(),'N');

update isee_function set parent_func_id=
(select a.id from (select id from isee_function where func_code='M000154' limit 1) a),`order`=1,
modifier='admin',gmt_modified=now() where func_code='M000071';

update isee_function set parent_func_id=
(select a.id from (select id from isee_function where func_code='M000154' limit 1) a),`order`=2,
modifier='admin',gmt_modified=now() where func_code='M000081';

update isee_function set parent_func_id=
(select a.id from (select id from isee_function where func_code='M000154' limit 1) a),`order`=3,
modifier='admin',gmt_modified=now() where func_code='M000082';

update isee_function set parent_func_id=
(select a.id from (select id from isee_function where func_code='M000154' limit 1) a),`order`=4,
modifier='admin',gmt_modified=now() where func_code='M000083';

update isee_function set parent_func_id=
(select a.id from (select id from isee_function where func_code='M000154' limit 1) a),`order`=5,
modifier='admin',gmt_modified=now() where func_code='M000084';

-- 更新角色菜单关系
insert into isee_role_func (func_code,role_id,creator,gmt_created,modifier,gmt_modified,is_deleted)
select 'M000153',
role_id,
'admin',now(),'admin',now(),'N'
from isee_role_func where func_code in ('M000021','M000152') and is_deleted='N' group by role_id;

insert into isee_role_func (func_code,role_id,creator,gmt_created,modifier,gmt_modified,is_deleted)
select 'M000154',
role_id,
'admin',now(),'admin',now(),'N'
from isee_role_func where func_code in ('M000071','M000081','M000082','M000083','M000084') and is_deleted='N' group by role_id;

insert into isee_role_func (func_code,role_id,creator,gmt_created,modifier,gmt_modified,is_deleted)
select 'M000155',
role_id,
'admin',now(),'admin',now(),'N'
from isee_role_func where func_code in ('M000151') and is_deleted='N' group by role_id;


-- 针对pre环境数据库的处理
-- update isee_function set func_code='M000076',api_path='/function/sub,/hosts/list,/page/list,/page' where id=70;
-- update isee_function set func_code='M000077',api_path='/function/sub,/processRef,/page/all,/hosts/list,/process/list,/processCheck,/process,/process/{processCode}' where id=71;
-- update isee_function set func_code='M000078',api_path='/function/sub,/hosts/query,/hosts' where id=72;
-- 响应调整角色菜单绑定关系
-- insert into isee_role_func(func_code,role_id,creator,gmt_created,modifier,gmt_modified,is_deleted) select 'M000076',role_id,'admin',now(),'admin',now(),'N' from isee_role_func where func_code='M000075';
-- insert into isee_role_func(func_code,role_id,creator,gmt_created,modifier,gmt_modified,is_deleted) select 'M000077',role_id,'admin',now(),'admin',now(),'N' from isee_role_func where func_code='M000075';
-- insert into isee_role_func(func_code,role_id,creator,gmt_created,modifier,gmt_modified,is_deleted) select 'M000078',role_id,'admin',now(),'admin',now(),'N' from isee_role_func where func_code='M000075';



-- 无数据权限的机构需要添加数据权限数据
insert into isee_agency_auth(agency_code,authorized_agency_code,creator,gmt_created,modifier,gmt_modified,is_deleted)
select code,code,'admin',now(),'admin',now(),'N' from isee_agency where code not in 
(select agency_code from isee_agency_auth where is_deleted='N') and is_deleted='N';

-- 更新版本管理历史数据
update isee_insure_fllow set gmt_last_operation = gmt_created ;


